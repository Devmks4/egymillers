import 'package:flutter/material.dart';

const Color scaffoldBackGround = Color(0xFFDAFFD3);
const Color primaryColor = Colors.teal;
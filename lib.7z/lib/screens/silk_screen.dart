import 'package:egymillers/screens/silk_table_screen.dart';
import 'package:egymillers/shared/styles/colors.dart';
import 'package:flutter/material.dart';
import 'package:egymillers/widgets/app_widgets.dart';
import '../widgets/app_button.dart';
import '../widgets/drop_menu.dart';
import 'package:egymillers/models/silk_table.dart';

class SilkScreen extends StatefulWidget {
  const SilkScreen({super.key});

  @override
  _SilkScreenState createState() => _SilkScreenState();
}

class _SilkScreenState extends State<SilkScreen> {
  /*-----------------Variables-------------------*/
  var measureType = ["GG", "XXX", "السلك"];
  late List<String?> measureValue ;
  int measureSelected = 1;
  late String? measureValueSelected  ;
  String dropdownvalue = "GG";
  var micronValue = "1800", holecmValue = "4.4", diameterValue = "500", percentageValue = "51";

  var searchIndex = 0;
  var searchTerm = '0';
  var errorMessage = " ";
  var formKey = GlobalKey<FormState>();
  var checkValidate = 0;
  /*---------------------------------------*/

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    measureValue = SilkTable.ggTable.map((row) => row['id']).toList();
    measureValueSelected = measureValue[0];
  }

  void fetchValues (value , table){
    var row = SilkTable.searchRow(value, table);
    if(row != null){
      micronValue = row['micron'].toString();
      holecmValue = row['holescm'].toString();
      diameterValue = row['diameter'].toString();
      percentageValue = row['percentage'].toString();
    }
    else{
      micronValue = "0";
      holecmValue = "0";
      diameterValue = "0";
      percentageValue = "0";
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: scaffoldBackGround,
      appBar: AppBar(
        backgroundColor: primaryColor,
        title: Text(
          'حساب مقاسات الحرير',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Center(
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              spacing: 12,
              children: [
                AppButton(
                  title: 'البحث بقيمة عدد الفتحات / سم',
                  onPress:
                      () => Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => SilkTableScreen(),
                        ),
                      ),
                ),
                Appspacer(),
                Flexible(
                  child: Column(
                    spacing: 16,
                    children: [
                      Row(
                        spacing: 16,
                        children: [
                          Expanded(
                            child: AppDropMenu(
                              menuList: measureValue,
                              dropdownvalue: measureValueSelected!,
                              onChanged: (String? value) {
                                setState(() {
                                  measureValueSelected = value!;
                                  if (measureSelected == 1){
                                    fetchValues(value, SilkTable.ggTable);
                                  }
                                  else if (measureSelected == 2){
                                    fetchValues(value, SilkTable.xxxTable);
                                  }
                                  else if (measureSelected == 3){
                                    fetchValues(value, SilkTable.metalTable);
                                  }
                                });
                              },
                            ),
                          ),
                          Expanded(
                            child: AppDropMenu(
                              menuList: measureType,
                              dropdownvalue: dropdownvalue,
                              onChanged: (String? value) {
                                setState(() {
                                  dropdownvalue = value!;
                                  if (value == 'GG')
                                  {
                                     measureValue = SilkTable.ggTable.map((row) => row['id']).toList();
                                     measureValueSelected = measureValue[0];
                                     measureSelected = 1;
                                     fetchValues(measureValueSelected, SilkTable.ggTable);
                                  }
                                  else if (value == 'XXX')
                                  {
                                    measureValue = SilkTable.xxxTable.map((row) => row['id']).toList();
                                    measureValueSelected = measureValue[0];
                                    measureSelected = 2;
                                    fetchValues(measureValueSelected, SilkTable.xxxTable);
                                  }
                                  else if (value == 'السلك')
                                  {
                                    measureValue = SilkTable.metalTable.map((row) => row['id']).toList();
                                    measureValueSelected = measureValue[0];
                                    measureSelected = 3;
                                    fetchValues(measureValueSelected, SilkTable.metalTable);
                                  }
                                });
                              },
                            ),
                          ),
                        ],
                      ),
                      Appspacer(),
                      Container(
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(16),
                          color: Colors.green[200],
                        ),
                        child: Padding(
                          padding: const EdgeInsets.all(16.0),
                          child: Row(
                            spacing: 16,
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: [
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisSize: MainAxisSize.min,
                                spacing: 16,
                                children: [
                                  Text(
                                    micronValue,
                                    style: TextStyle(
                                      fontSize: 20,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  Text(
                                    holecmValue,
                                    style: TextStyle(
                                      fontSize: 20,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  Text(
                                    diameterValue,
                                    style: TextStyle(
                                      fontSize: 20,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  Text(
                                    percentageValue,
                                    style: TextStyle(
                                      fontSize: 20,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ],
                              ),
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.end,
                                spacing: 16,
                                children: [
                                  Text(
                                    'ميكرون',
                                    style: TextStyle(
                                      fontSize: 20,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  Text(
                                    'عدد الفتحات / سم',
                                    style: TextStyle(
                                      fontSize: 20,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  Text(
                                    'سمك الخيط (ميكرون)',
                                    style: TextStyle(
                                      fontSize: 20,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  Text(
                                    'كفاءة النخل (%)',
                                    style: TextStyle(
                                      fontSize: 20,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}




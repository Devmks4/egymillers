
import 'package:flutter/material.dart';

class HomeCard {

  String? title;
  String? image;
  Widget? rOUTE;

  HomeCard({this.title, this.image,this.rOUTE});
}

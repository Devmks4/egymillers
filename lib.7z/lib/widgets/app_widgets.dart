import 'package:flutter/material.dart';

class Appspacer extends StatelessWidget {
  const Appspacer({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 1,
      color: Colors.grey[300],
    );
  }
}


